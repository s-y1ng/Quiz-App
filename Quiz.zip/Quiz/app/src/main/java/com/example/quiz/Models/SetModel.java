package com.example.quiz.Models;

public class SetModel {

    String setName;

    public SetModel(String setName){
        this.setName=setName;
    }

    public String getSetName() {
        return setName;
    }

    public void setSetName(String setName) {
        this.setName = setName;
    }
}
