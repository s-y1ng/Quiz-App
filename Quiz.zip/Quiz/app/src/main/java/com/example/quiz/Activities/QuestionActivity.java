package com.example.quiz.Activities;

import android.animation.Animator;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.quiz.Models.QuestionModel;
import com.example.quiz.R;
import com.example.quiz.databinding.ActivityQuestionBinding;

import java.util.ArrayList;

public class QuestionActivity extends AppCompatActivity {

    ArrayList<QuestionModel> list = new ArrayList<>();
    private int count = 0;
    private int position=0;
    private int score = 0;
    CountDownTimer timer;
    ActivityQuestionBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityQuestionBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().hide();

        resetTimer();
        timer.start();

        String setName = getIntent().getStringExtra("set");

        if(setName.equals("SET-1")){
            setOne();
        }
        else if (setName.equals("SET-2")){
            setTwo();
        }
        else if (setName.equals("SET-3")){
            setThree();
        }
        for(int i=0; i<4;i++){
            binding.optionContainer.getChildAt(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    checkAnswer((Button)v);
                }
            });
        }

        playAnimation(binding.question,0,list.get(position).getQuestion());

        binding.btnNext.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                if(timer != null){
                    timer.cancel();
                }
                timer.start();
                binding.btnNext.setEnabled(false);
                binding.btnNext.setAlpha((float)0.3);
                enableOption(true);
                position++;

                if(position == list.size()){
                    Intent intent = new Intent(QuestionActivity.this, ScoreActivity.class);
                    intent.putExtra("score",score);
                    intent.putExtra("total",list.size());
                    startActivity(intent);
                    finish();
                    return;
                }

                count = 0;

                playAnimation(binding.question,0,list.get(position).getQuestion());

            }
        });

    }

    private void resetTimer() {
        timer = new CountDownTimer(30000,1000) {
            @Override
            public void onTick(long l) {
                binding.time.setText(String.valueOf(l/1000));
            }

            @Override
            public void onFinish() {
                Dialog dialog = new Dialog(QuestionActivity.this);
                dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
                dialog.setCancelable(false);
                dialog.setContentView(R.layout.timeout_dialogue);
                dialog.findViewById(R.id.tryAgain).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(QuestionActivity.this,SetsActivity.class);
                        startActivity(intent);
                        finish();
                    }
                });
                dialog.show();
            }
        };
    }


    private void playAnimation(View view, int value, String data) {
        view.animate().alpha(value).scaleX(value).scaleY(value).setDuration(500).setStartDelay(100)
                .setInterpolator(new DecelerateInterpolator()).setListener(new Animator.AnimatorListener() {
                    @Override
                    public void onAnimationStart(@NonNull Animator animation) {



                        if (value == 0 && count < 4){

                            String option = "";

                            if (count ==0){
                                option = list.get(position).getOptionA();
                            }
                            else if (count == 1){
                                option = list.get(position).getOptionB();
                            }
                            else if (count == 2){
                                option = list.get(position).getOptionC();
                            }
                            else if (count == 3){
                                option = list.get(position).getOptionD();
                            }

                            playAnimation(binding.optionContainer.getChildAt(count),0,option);
                            count++;
                        }

                    }

                    @Override
                    public void onAnimationEnd(@NonNull Animator animation) {

                        if(value == 0){
                            try {
                                ((TextView) view).setText(data);
                                binding.totalQuestion.setText(position+1+"/"+list.size());

                            } catch (Exception e){
                                ((Button)view).setText(data);
                            }

                            view.setTag(data);
                            playAnimation(view,1,data);

                        }

                    }

                    @Override
                    public void onAnimationCancel(@NonNull Animator animation) {

                    }

                    @Override
                    public void onAnimationRepeat(@NonNull Animator animation) {

                    }
                });
    }

    private void enableOption(boolean enable) {

        for(int i=0;i<4;i++){
            binding.optionContainer.getChildAt(i).setEnabled(enable);

            if(enable){
                binding.optionContainer.getChildAt(i).setBackgroundResource(R.drawable.btn_opt);
            }
        }


    }

    private void checkAnswer(Button selectedOption) {

        if(timer != null){
            timer.cancel();
        }

        binding.btnNext.setEnabled(true);
        binding.btnNext.setAlpha(1);

        if(selectedOption.getText().toString().equals(list.get(position).getCorrectAnswer())){
            score++;
            selectedOption.setBackgroundResource(R.drawable.right_answ);
        }
        else{
            selectedOption.setBackgroundResource(R.drawable.wrong_answ);

            Button correctOption = (Button) binding.optionContainer.findViewWithTag(list.get(position).getCorrectAnswer());
            correctOption.setBackgroundResource(R.drawable.right_answ);
        }

    }



    private void setTwo() {
        list.add(new QuestionModel("1. Kingdom Of Sarawak is founded by who and in what year?",
                "A. Sir James Brooke in 1842",
                "B. Charles Vyner Brooke in 1959",
                "C. Sir Adam Brooke in 1730",
                "D. Henry Vyner Brooke in 1835",
                "A. Sir James Brooke in 1842"));
        list.add(new QuestionModel("2. Which of the following is not the political factors that drives British intervention in the Malay States?",
                "A. The industrial revolution in Europe",
                "B. Expansion of other colonial powers",
                "C. Desire to take control of local administrations",
                "D. None of the above",
                "A. The industrial revolution in Europe"));
        list.add(new QuestionModel("3. What was the factor that lead to the formation of the Federated Malay States?",
                "A. Reduction in the authority of Malay rulers",
                "B. Controlling the powers of Residents",
                "C. Increasing the administrative cost",
                "D. Expansion of the colonial territory in Malaya",
                "A. Reduction in the authority of Malay rulers"));
        list.add(new QuestionModel("4.  On December 10 1941, what are the two British battleship that were sunk by the Japanese?","A. HMS Winston and HMS Repulse","B. HMS Prince Of Wales and HMS John Mendela","C. HMS Prince Of Wales and HMS Repulse","D. HMS Birmingham and HMS Manchester","A. HMS Winston and HMS Repulse"));
        list.add(new QuestionModel("5. What is the Kempeitai are responsible for?","A. Giving food to the local","B. Managing local news paper","C. Act as a cannon fodder in the frontline","D. Physcological operations and propaganda","D. Physcological operations and propaganda"));
    }

    private void setOne() {
        list.add(new QuestionModel("1. When did the Malayan Union become existence and who is the governor?","A. April 10 1946, Sir Howard Gent","B. April 1 1946, Sir Edward Gent","C. May 1 1946, Sir Johnny Gent","D. May 30 1946, Sir Henry Gent","B. April 1 1946, Sir Edward Gent"));
        list.add(new QuestionModel("2. What are the objectives of the Briggs Plan?","A. To cut off the supply of communist among the support of the population", "B. To lure the communist into the urban area and kill them","C. To make the communist surrender by providing them necessary supply","D. To imprisont any civillian who collaborate with the communist","A. To cut off the supply of communist among the support of the population"));
        list.add(new QuestionModel("3. The Federation Of Malaysia that consists of Sabah, Sarawak, and  Singapore was officially declared on?", "A. August 18, 1957", "B. September 16, 1963","C. August 1, 1964", "D. August 29, 1962","B. September 16, 1963"));
        list.add(new QuestionModel("4. What is the below mega project that was build under the leadership of Dr Mahathir Bin Mohammed?","A. Empire States Building", "B. Petronas Twin Tower", "C. Maybank Tower", "D. Millenium Tower","B. Petronas Twin Tower"));
        list.add(new QuestionModel("5. Who is the British High Commissioner that had been killed by MNLA?","A. Sir Jerry Gurney","B. Sir Thomas Kerry","C. Sir Martin Jeremy","D. Sir Henry Gurney","D. Sir Henry Gurney"));
    }

    private void setThree() {
        list.add(new QuestionModel("1. Why Malayan Union received strong opposion from the Malays?",
                "A. The methods used by Sir Harold Michael to gain approval from the Sultans and cause Sultans to lose power",
                "B. Malayan Union plan was to expel the Malay to the rural areas",
                "C. Malayan Union plan was to cut off the suppy of local citizens and supply the British Crown Colony",
                "D. Malayan Union prevented Malays from leaving the country freely",
                "A. The methods used by Sir Harold Michael to gain approval from the Sultans and cause Sultans to lose power"));
        list.add(new QuestionModel(
                "2. The Malayan Union was replaced by what?",
                "A. Federation Of The Union",
                "B. Federation Of United",
                "C. Federation Of Malaya",
                "D. Federation Of The Malayan People",
                "C. Federation Of Malaya"));
        list.add(new QuestionModel("3. The merging of the British colonies in South-East Asia was originally whose idea?",
                "A. Lord Mountbatten",
                "B. Lord Brassey",
                "C. Lord Curzon",
                "D. Lord Minto",
                "B. Lord Brassey"));

        list.add(new QuestionModel("4. Which country did not support the formation of Malaysia",
                "A. Singapore",
                "B. China",
                "C. Indonesia",
                "D. Philippines",
                "D. Philippines"));

        list.add(new QuestionModel("5. Who approved the Malaysia Act of 1963?",
                "A. Churchill",
                "B. Ramset McDonald",
                "C. Margaret Thatcher",
                "D. Queen Elizabeth II",
                "A. Churchill"));
    }
}